import json
import requests


# def initialdatapull(ticker):
#         url = "http://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol=" + ticker + "&outputsize=full&apikey=NG9C9EPVYBMQT0C8"
        
#         response = requests.get(url)
#         data = json.loads(response.text)
       
#         lines = []
        
#         with open("/home/ubuntu/environment/Final_Project/" + ticker + ".csv", "w") as file:
#             for date in data["Time Series (Daily)"].keys():
#                 lines.append(date + "," + data["Time Series (Daily)"][date]["4. close"] + "\n")
#                 # file.write(date + "," + data["Time Series (Daily)"][date]["4. close"] + "\n")
                
#             file.writelines(lines[::-1])
#     return    
        
def meanReversionstrat(prices):
    i = 0 #helps us iterate through the list 
    buy = 0 #bought price
    first_buy = 0 #our first bought price
    tot_profit = 0  #overall profit
    
    for price in prices: #loop through list prices
        current_price = price
        if i > 4: #makes sure we don't go outside of list range
            avg = round((prices[i-1]+prices[i-2]+prices[i-3]+prices[i-4]+prices[i-5])/5,2) #calculates 5 day moving average
           
            if current_price < avg *.98 and buy == 0:  #buy conditions
                if current_price < avg * 0.98 and first_buy == 0: #assign our first purchase to first_buy
                    first_buy = current_price
                buy = current_price
                print("bought at: ", buy) #what we bought it at
            elif current_price > avg * 1.02 and buy != 0: #sell conditions
                print("selling at: ", current_price)
                tot_profit += current_price - buy  #update our total profit
                print("trade profit: ", round(current_price - buy,2)) #shows our profit from trade
                buy = 0 #reset the buy variable because we sold all we had 
            
        i += 1 #update iteration
    
    print("---------------------------") # neat line :)
    print("Total Trade profit: ", round(tot_profit,2)) #total profit
    print("First buy: ", first_buy) #what our first buy was 
    print("% Return: ", round((tot_profit / first_buy)*100,2), end="%") #our % return
    
    returns = (tot_profit / first_buy) * 100 
    
    return round(tot_profit), round(returns)
    
    
    
def simpleMovingAvgstrat(prices):
    i = 0 #helps us iterate through the list 
    buy = 0 #bought price
    first_buy = 0 #our first bought price
    tot_profit = 0  #overall profit
    
    for price in prices: #loop through list prices
        current_price = price
        if i > 4: #makes sure we don't go outside of list range
            avg = round((prices[i-1]+prices[i-2]+prices[i-3]+prices[i-4]+prices[i-5])/5,2) #calculates 5 day moving average
            if current_price > avg and buy == 0:
                if first_buy == 0:
                    first_buy = current_price
                buy = current_price
                print("bought at:", buy)
            elif current_price < avg and buy != 0:
                print("selling at:", current_price)
                tot_profit = (current_price - buy)
                print("trade profit:", round((current_price-buy),2))
                buy = 0
                
        i += 1 #update iteration
    
    print("---------------------------") # neat line :)
    print("Total Trade profit: ", round(tot_profit,2)) #total profit
    print("First buy: ", first_buy) #what our first buy was 
    print("% Return: ", round((tot_profit / first_buy)*100,2), end="%")  #our % return
    
    returns = (tot_profit / first_buy) * 100
    return round(tot_profit), round(returns)
    
    
# tickers = ["GPRO","WMT","JPM","ISRG","META","MSTR","COST","F","T","GOOG"]
tickers = ["COST"]
results = {}

def bollingerStrat(prices):
    i = 0 #helps us iterate through the list 
    buy = 0 #bought price
    first_buy = 0 #our first bought price
    tot_profit = 0  #overall profit
    
    for price in prices: #loop through list prices
        current_price = price
        if i > 4: #makes sure we don't go outside of list range
            avg = round((prices[i-1]+prices[i-2]+prices[i-3]+prices[i-4]+prices[i-5])/5,2) #calculates 5 day moving average
            if current_price > avg * 1.05 and buy == 0:
                if first_buy == 0:
                    first_buy = current_price
                buy = current_price
                print("bought at:", buy)
            elif current_price < avg * 0.95 and buy != 0:
                print("selling at:", current_price)
                tot_profit = (current_price - buy)
                print("trade profit:", round((current_price-buy),2))
                buy = 0
                
        i += 1 #update iteration
    
    print("---------------------------") # neat line :)
    print("Total Trade profit: ", round(tot_profit,2)) #total profit
    print("First buy: ", first_buy) #what our first buy was 
    print("% Return: ", round((tot_profit / first_buy)*100,2), end="%")  #our % return
    
    returns = (tot_profit / first_buy) * 100
    return round(tot_profit), round(returns)
        
    
# define function saveResults
def saveResults(results):  #only one line of code
    json.dump(results, open("/home/ubuntu/environment/Final_Project/results.json","w"), indent = 4)  # dumps results into a json file
    
    
def append_data(ticker):
    #pull from api
    url = "http://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol=" + ticker + "&outputsize=full&apikey=NG9C9EPVYBMQT0C8"
    response = requests.get(url)
    data = json.loads(response.text)
       
    #check the date from csv file
    with open("/home/ubuntu/environment/Final_Project/" + ticker + ".csv", "r") as csv_file:
        csv_lines = csv_file.readlines()
    last_day = csv_lines[-1].split(",")[0]
     
    #date comparison with api
    new_lines = []
    
    with open("/home/ubuntu/environment/Final_Project/" + ticker + ".csv", "a") as file:
        for date in data["Time Series (Daily)"].keys():
            if date == last_day:
                break
            else:
                new_lines.append(date+","+data["Time Series (Daily)"][date]["4. close"]+ "\n")
            file.writelines(new_lines[::-1])
            
    pass
    #add everything new to the csv file
    
    
for ticker in tickers:   # loop through the list of tickers
        # initialdatapull(ticker)  #ONLY RUN THIS CODE ONCE
        prices = [round(float(line.split(",")[1]),2) for line in open("/home/ubuntu/environment/Final_Project/"+ticker+".csv").readlines()]  #list comprehension
        
        mr_profit, mr_returns = meanReversionstrat(prices)  #sets variables for mr
        sma_profit, sma_returns = simpleMovingAvgstrat(prices) #sets variables for sma
        
        results[ticker+"_prices"] = prices  #adding prices to the dictiionary
        results[ticker+"_mr_profit"] = mr_profit #adding profits and returns to the dictioonary
        results[ticker+"_mr_results"] = mr_returns
        results[ticker+"_sma_profit"] = sma_profit
        results[ticker+"_sma_results"] = sma_returns
        
        append_data(ticker)    
    